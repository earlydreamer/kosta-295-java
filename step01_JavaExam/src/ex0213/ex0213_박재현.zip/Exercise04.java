package ex0213.ex0213_박재현;

public class Exercise04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int pencils = 534;
		int students = 30;
		
		int pencilsPerStudent = pencils / students;
		
		System.out.println(pencilsPerStudent);
		
		int pencilsLeft = pencils%students;
		System.out.println(pencilsLeft);
	


	}

}
