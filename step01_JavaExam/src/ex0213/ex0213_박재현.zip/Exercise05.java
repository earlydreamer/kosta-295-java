package ex0213.ex0213_박재현;

public class Exercise05 {
	
	public static void main (String args[]) {
		
		int value = 356;
		System.out.println(value/100*100);
		
		
	}

}
